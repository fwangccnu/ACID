#!/usr/bin/python
import re,os
fi=open('FDBD2DB_bak').readlines()
fo=open('FDBD2DB_bak.csv','w')
for line in fi:
	if '_' in line:
		fo.write(line.split(',')[0]+',"'+line.split(',')[1][:-2]+'"\n')
	else:
		fo.write(line)
fo.close()
